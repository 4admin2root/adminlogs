#!/usr/bin/env python
from pylab import *


gcf().text(0.5, 0.95,
           'Distance Histograms by Category is a really long title')

show()
