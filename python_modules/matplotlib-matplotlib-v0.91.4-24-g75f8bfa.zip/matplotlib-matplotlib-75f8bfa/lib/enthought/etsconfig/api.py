from enthought.etsconfig.version import version, version as __version__


from etsconfig import ETSConfig
